
public class Packed_switch {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	    int choiceColor = 20;  


        switch (choiceColor) {
            case 1:  
            	System.out.println("Yellow"); 
            	break;
            case 20:  
            	System.out.println("Green");
            	break;
            case 30:  
            	System.out.println("Orange"); 
            	break;
            case 40:  
            	System.out.println("Brown"); 
            	break;
            case 50:  
            	System.out.println("Red"); 
            	break;

            default: 
            	System.out.println("No Color Found");
            	break;
        }
	}

}
