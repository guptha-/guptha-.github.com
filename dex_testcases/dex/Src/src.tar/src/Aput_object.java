
public class Aput_object {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stu
		String[] arr = new String[2];       
        arr[0] = "hello";
		//System.out.println("Result is hello");
		System.out.println(arr[0]);

	}

}
