
public class Div_float_2addr {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        float a = 2.7f;
        float b = 3.14f;
        float c = 0f;
        c = a/b;
        c+=1;
        //System.out.println("Result is 1.8598726f");
		System.out.println(c);
		

	}
}
