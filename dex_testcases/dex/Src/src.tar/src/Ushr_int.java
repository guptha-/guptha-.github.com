public class Ushr_int {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Shifts the bits of n left p positions.
		// Zero bits are shifted into the low-order positions.
		// a << 2 = 24
		int c;
		c = 15 >>> 1;
		//System.out.println("Result should be 7");
		System.out.println(c);

	}

}
