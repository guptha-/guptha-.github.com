
public class Add_double {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

        double x, y, z;
        x =2.7;
        y = 3.14;
        z = x+ y;
    //    System.out.println("Add_ double result should be 5.84");		
        System.out.println (z);
	}

}
