
public class Const_16 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = -10000;
		int b = -10000;
		int c;
		c = a + b;
		//System.out.println("Result is -20000");
		System.out.println(c);

	}

}
