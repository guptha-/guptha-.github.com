
public class Float_to_int {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		float a = 2.999999f;
		int b = (int) a;

       // System.out.println("Result should be 2");		
        System.out.println (b);
	}

}
