
public class Sub_int_lit8 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int x, y, z;
        x = 8;
        y = 4;
        z = x - y;
        //System.out.println("Result should be 4");		
        System.out.println (z);

	}

}
