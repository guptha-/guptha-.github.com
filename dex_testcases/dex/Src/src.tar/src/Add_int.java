
public class Add_int {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        int x, y, z;
        x = 8;
        y = 4;
        z = x+ y;
       // System.out.println("Add_ int result should be 12");		
        System.out.println (z);

	}

}
