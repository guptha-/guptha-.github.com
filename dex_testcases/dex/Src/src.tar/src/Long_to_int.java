public class Long_to_int {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		long a = -123456789l;
		int b = (int) a;

		//System.out.println("Result should be -123456789");
		System.out.println(b);

	}

}
