public class neg_to_long {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		long a = 123123123272432432l;
		long b = a;

		//System.out.println("Result should be -123123123272432432l");
		System.out.println(-b);


	}

}
