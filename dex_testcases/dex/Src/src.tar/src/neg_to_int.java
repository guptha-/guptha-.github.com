
public class neg_to_int {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 1;
		int b = a;

		//System.out.println("Result should be -1");
		System.out.println(-b);

	}

}
