
public class Div_int_lit8 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int x, y, z;
        x = 8;
        y = 4;
        z = x/ y;
        //System.out.println("Div_ int result should be 2");		
        System.out.println (z);

	}

}
