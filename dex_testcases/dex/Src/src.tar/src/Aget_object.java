
public class Aget_object {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String[] arr = new String[] {"a", "b"};
     //   System.out.println("Result is a");
        System.out.println(arr[0]);
        

	}

}
