
public class New_array {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = new int[10];

		//System.out.println("Result is 10");
		System.out.println(a.length);

	}

}
