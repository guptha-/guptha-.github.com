
public class Aput {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = new int[2];
		arr[1] = 100000000;

		//System.out.println("Result is 100000000");
		System.out.println(arr[1]);

	}

}
