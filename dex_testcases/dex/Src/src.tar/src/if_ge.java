public class if_ge {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 21;
		int b = 20;

		if (a >= b)
			// System.out.println("Result should be True");
			System.out.println(a >= b);

	}

}
