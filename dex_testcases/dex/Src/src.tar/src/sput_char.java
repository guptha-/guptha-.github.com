public class sput_char {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Setter_schar t = new Setter_schar();

		//System.out.println("Result should be A");
		System.out.println(t.s_set(65));

	}

}

class Setter_schar {

	public static char s_set(int s) {
		return (char) s;
	}
}
