public class Sub_double {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		double x, y, z;
		x = 2.7d;
		y = 3.14d;
		z = x - y;

		//System.out.println("Reesult should be -0.43999999999999995");
		System.out.println(z);
	}

}
