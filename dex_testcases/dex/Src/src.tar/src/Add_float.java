
public class Add_float {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        float x, y, z;
        x =2.7f;
        y = 3.14f;
        z = x+ y;
        //System.out.println("Add_ float result should be 5.84");		
        System.out.println (z);

	}

}
