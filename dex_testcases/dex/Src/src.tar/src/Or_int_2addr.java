
public class Or_int_2addr {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 15;
		int b = 8;
		int c = 0;
		// Or operation =a | b = 2
		c = a | b;
		c+=1;
		//System.out.println("a | b = 16");
		System.out.println(c);

	}

}
