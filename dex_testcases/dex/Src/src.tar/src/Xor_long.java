public class Xor_long {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		long a = 23423432423777l;
		long b = 23423432423778l;
		long c = 0;
		// XOR operation =a ^ b
		c = a ^ b;
		//System.out.println("a ^ b = 3");
		System.out.println(c);

	}

}
