
public class Aput_char {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        char[] arr = new char[2];
        arr[1] = 'g';
		//System.out.println("Result is g");
		System.out.println(arr[1]);
        


	}

}
