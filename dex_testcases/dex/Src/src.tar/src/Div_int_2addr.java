
public class Div_int_2addr {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        int x, y, z;
        x = 8;
        y = 4;
        z = x/ y;
        z+=1;
        //System.out.println("Div_ int result should be 3");		
        System.out.println (z);

	}

}