
public class Add_long {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
        long x, y, z;
        x = 12345678l;
        y = 87654321l;
        z = x+ y;
       // System.out.println("Add_ int result should be 99999999");		
        System.out.println (z);

	}

}
