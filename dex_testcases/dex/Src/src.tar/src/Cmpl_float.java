
public class Cmpl_float {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float x, y;
		x = 3.14f;
		y = 2.7f;

		if (x > y)
			System.out.println(true);
		else
			System.out.println(false);

	}

}
