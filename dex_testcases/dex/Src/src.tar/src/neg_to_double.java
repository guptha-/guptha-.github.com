
public class neg_to_double {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 double a = 1d;
		double b = a;

		//System.out.println("Result should be -1.0");
		System.out.println(-b);

	}

}
