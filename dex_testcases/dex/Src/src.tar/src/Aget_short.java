
public class Aget_short {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	       short[] arr = new short[2];
	       arr[1] = 10000;
	       //System.out.println("Result is 10000");
	       System.out.println(arr[1]);

	}

}
