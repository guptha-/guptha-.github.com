public class Sub_int_2addr {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x, y, z;
		x = 8;
		y = 4;
		z = x - y;
		z += 1;
		//System.out.println("Result should be 5");
		System.out.println(z);

	}

}
