public class Float_to_double {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		float a = .5f;
		double b = (double) a;

		// System.out.println("Result should be .5d");
		System.out.println(b);

	}

}
