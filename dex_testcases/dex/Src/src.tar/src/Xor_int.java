
public class Xor_int {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 15;
		int b = 8;
		int c = 0;
		// XOR operation =a ^ b
		c = a ^ b;
		//System.out.println("a ^ b = 7");
		System.out.println(c);

	}

}
